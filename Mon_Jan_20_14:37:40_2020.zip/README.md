# Funnel-Cake
A Python utility to manage Spotify Playlists
